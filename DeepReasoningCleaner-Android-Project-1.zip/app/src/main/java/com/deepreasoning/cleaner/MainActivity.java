package com.deepreasoning.cleaner;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.graphics.Bitmap;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private ImageView ivIconPreview;
    private MaterialButton btnGenerateAndSave;
    private ProgressBar progressBar;
    private TextView tvStatus;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ivIconPreview = findViewById(R.id.ivIconPreview);
        btnGenerateAndSave = findViewById(R.id.btnGenerateAndSave);
        progressBar = findViewById(R.id.progressBar);
        tvStatus = findViewById(R.id.tvStatus);

        // عند فتح التطبيق، نعرض الأيقونة مسبقاً في واجهة المستخدم
        Bitmap initialBitmap = IconGenerator.generateIcon();
        ivIconPreview.setImageBitmap(initialBitmap);

        btnGenerateAndSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawAndSaveToGallery();
            }
        });
    }

    /**
     * دالة رسم الأيقونة وحفظها مباشرة في معرض الصور (Gallery)
     */
    private void drawAndSaveToGallery() {
        progressBar.setVisibility(View.VISIBLE);
        btnGenerateAndSave.setEnabled(false);
        tvStatus.setText("جاري رسم الأيقونة وحفظها في المعرض...");

        executor.execute(() -> {
            // 1) رسم الأيقونة في الخلفية
            Bitmap iconBitmap = IconGenerator.generateIcon();

            // 2) حفظ في معرض صور الهاتف (MediaStore)
            boolean success = saveToDeviceGallery(iconBitmap);

            runOnUiThread(() -> {
                progressBar.setVisibility(View.GONE);
                btnGenerateAndSave.setEnabled(true);
                ivIconPreview.setImageBitmap(iconBitmap);

                if (success) {
                    tvStatus.setText("تم حفظ الأيقونة في معرض الصور بنجاح! ✓");
                    Toast.makeText(MainActivity.this, 
                        "تم حفظ deep-reasoning-cleaner.png في المعرض بنجاح! 📸", 
                        Toast.LENGTH_LONG).show();
                } else {
                    tvStatus.setText("تعذر حفظ الأيقونة. يرجى التحقق من أذونات التخزين.");
                    Toast.makeText(MainActivity.this, "فشل الحفظ في المعرض", Toast.LENGTH_SHORT).show();
                }
            });
        });
    }

    /**
     * حفظ الـ Bitmap في المعرض مع دعم كامل لجميع إصدارات أندرويد (Scoped Storage لأندرويد 10+ وتوافق للإصدارات القديمة)
     */
    private boolean saveToDeviceGallery(Bitmap bitmap) {
        String filename = "deep-reasoning-cleaner-" + System.currentTimeMillis() + ".png";
        OutputStream outputStream = null;

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // نظام Android 10 فما فوق (Scoped Storage بدون الحاجة لأذونات معقدة)
                ContentResolver resolver = getContentResolver();
                ContentValues contentValues = new ContentValues();
                contentValues.put(MediaStore.MediaColumns.DISPLAY_NAME, filename);
                contentValues.put(MediaStore.MediaColumns.MIME_TYPE, "image/png");
                contentValues.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/DeepReasoning");
                contentValues.put(MediaStore.MediaColumns.IS_PENDING, 1);

                Uri imageUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues);
                if (imageUri != null) {
                    outputStream = resolver.openOutputStream(imageUri);
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream);
                    contentValues.clear();
                    contentValues.put(MediaStore.MediaColumns.IS_PENDING, 0);
                    resolver.update(imageUri, contentValues, null, null);
                    return true;
                }
            } else {
                // إصدارات أندرويد 9 فما دون
                File picturesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
                File appDir = new File(picturesDir, "DeepReasoning");
                if (!appDir.exists()) {
                    appDir.mkdirs();
                }
                File imageFile = new File(appDir, filename);
                outputStream = new FileOutputStream(imageFile);
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream);

                // إبلاغ ماسح الوسائط ليظهر الملف فوراً في تطبيق "الصور/المعرض"
                MediaScannerConnection.scanFile(this, 
                    new String[]{imageFile.getAbsolutePath()}, 
                    new String[]{"image/png"}, null);
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (outputStream != null) {
                try {
                    outputStream.close();
                } catch (IOException ignored) {}
            }
        }
        return false;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdown();
    }
}
