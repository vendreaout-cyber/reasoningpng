package com.deepreasoning.cleaner;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;

/**
 * IconGenerator - مولّد أيقونة Deep Reasoning
 * تم تحويل هذا الكود حرفياً من سكريبت بايثون (PIL/Pillow) إلى Native Android Java.
 */
public class IconGenerator {

    public static final int ICON_SIZE = 512;

    /**
     * رسم الأيقونة بالكامل على Bitmap بدقة 512x512
     */
    public static Bitmap generateIcon() {
        // إنشاء صورة 512x512 بخلفية شفافة (ARGB_8888)
        Bitmap bitmap = Bitmap.createBitmap(ICON_SIZE, ICON_SIZE, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);

        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        // 1) الخلفية: مستطيل بحواف دائرية (radius = 112, fill = #0B1220)
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(11, 18, 32)); // #0B1220
        RectF bgRect = new RectF(0, 0, 512, 512);
        canvas.drawRoundRect(bgRect, 112f, 112f, paint);

        // إطار خفيف: [16, 16, 496, 496] radius = 96, stroke = 2, color = #1F2937
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(2f);
        paint.setColor(Color.rgb(31, 41, 55)); // #1F2937
        RectF borderRect = new RectF(16, 16, 496, 496);
        canvas.drawRoundRect(borderRect, 96f, 96f, paint);

        // 2) حرف C (قوس): المركز (256, 256) ونصف القطر 180.
        // في PIL القوس من 45° إلى 315° (يترك فتحة يمين).
        // في أندرويد: startAngle = 45، sweepAngle = 270 (315 - 45 = 270)
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(28f);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setColor(Color.rgb(34, 211, 238)); // #22D3EE
        RectF arcBounds = new RectF(256 - 180, 256 - 180, 256 + 180, 256 + 180);
        canvas.drawArc(arcBounds, 45f, 270f, false, paint);

        // 3) خطوط التوصيل والشبكة العصبية (لمسة التفكير)
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(4f);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setColor(Color.argb(128, 34, 211, 238)); // شفافية 50%
        canvas.drawLine(120, 256, 180, 220, paint);
        canvas.drawLine(120, 256, 180, 292, paint);

        // 4) النقاط التقنية (Dots)
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(34, 211, 238));
        canvas.drawCircle(383, 129, 10f, paint); // نقطة يمين أعلى
        canvas.drawCircle(383, 383, 10f, paint); // نقطة يمين أسفل
        canvas.drawCircle(120, 256, 8f, paint);  // نقطة يسار

        // 5) حرف R (توسيط النص بدقة)
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.WHITE);
        paint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        paint.setTextSize(260f);
        paint.setTextAlign(Paint.Align.CENTER);

        Paint.FontMetrics fm = paint.getFontMetrics();
        // معادلة توسيط الارتفاع الدقيق في خطوط أندرويد:
        float centerY = 256f - ((fm.descent + fm.ascent) / 2f) + 15f;
        canvas.drawText("R", 256f, centerY, paint);

        // 6) وميض النظافة والذكاء (نجمة رباعية Sparkle Polygon)
        paint.setColor(Color.argb(242, 255, 255, 255)); // أبيض بنقاء 95%
        Path sparklePath = new Path();
        sparklePath.moveTo(400, 80);
        sparklePath.lineTo(408, 100);
        sparklePath.lineTo(428, 108);
        sparklePath.lineTo(408, 116);
        sparklePath.lineTo(400, 136);
        sparklePath.lineTo(392, 116);
        sparklePath.lineTo(372, 108);
        sparklePath.lineTo(392, 100);
        sparklePath.close();
        canvas.drawPath(sparklePath, paint);

        return bitmap;
    }
}
