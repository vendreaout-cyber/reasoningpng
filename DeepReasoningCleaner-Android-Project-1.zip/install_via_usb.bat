@echo off
chcp 65001 > nul
echo ====================================================
echo  تثبيت تطبيق Deep Reasoning عبر كابل الـ USB
echo ====================================================
echo.
echo 1. تأكد من توصيل هاتفك عبر كابل USB.
echo 2. تأكد من تفعيل "تصحيح أخطاء USB" (USB Debugging).
echo.
adb devices
echo.
echo جاري تثبيت التطبيق على هاتفك...
adb install -r app/build/outputs/apk/debug/app-debug.apk
if %errorlevel% equ 0 (
    echo.
    echo [✓] تم التثبيت بنجاح! جاري تشغيل التطبيق على الهاتف...
    adb shell am start -n com.deepreasoning.cleaner/.MainActivity
) else (
    echo.
    echo [X] فشل التثبيت. تأكد من تفعيل USB Debugging والسماح للكمبيوتر بالاتصال.
)
pause
